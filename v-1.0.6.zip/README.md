# eksi-search extension
Search selected text on Ekşi Sözlük
### Get it on:

**Firefox:** https://addons.mozilla.org/en-US/firefox/addon/ek%C5%9Fi-search/

### Screenshots:

#### Firefox:

![firefox1.png](./screenshots/firefox1.png)

![firefox2.png](./screenshots/firefox2.png)
